# Santiago Salazar Gil
# Código: 8970728
# Sistemas Operativos
# Assignment 3

import matplotlib.pyplot as plt
import csv
import os

def graficar(nombre_csv, titulo, nombre_png):
    if not os.path.exists(nombre_csv):
        print(f"[ERROR] No existe {nombre_csv}")
        return

    pasos = []
    posiciones = []

    with open(nombre_csv, "r") as f:
        reader = csv.reader(f)
        next(reader)  # saltar encabezado
        for row in reader:
            pasos.append(int(row[0]))       # paso
            posiciones.append(int(row[1]))  # posición correcta

    plt.figure(figsize=(10, 5))
    plt.plot(pasos, posiciones)
    plt.title(titulo)
    plt.xlabel("Orden de atención")
    plt.ylabel("Cilindro")
    plt.grid(True)
    plt.savefig(nombre_png)
    plt.close()

    print(f"[OK] Gráfica exportada → {nombre_png}")

def main():
    graficar("fcfs.csv",  "Movimiento del cabezal - FCFS",  "grafica_fcfs.png")
    graficar("scan.csv",  "Movimiento del cabezal - SCAN",  "grafica_scan.png")
    graficar("cscan.csv", "Movimiento del cabezal - C-SCAN","grafica_cscan.png")

if __name__ == "__main__":
    main()