// Santiago Salazar Gil
// Código: 8970728
// Sistemas Operativos
// Assignment 3

#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;

int top = 4999;

// Exportar trayectoria

void exportarCSV(const string &filename, const vector<int> &path) {
    ofstream file(filename);
    file << "paso,posicion\n";
    for (int i = 0; i < path.size(); i++) {
        file << i << "," << path[i] << "\n";
    }
    file.close();
}

// FCFS

int calcularFCFS(const vector<int> &requests, int head, vector<int> &path) {
    int movimientoTotal = 0;
    int pos = head;

    path.push_back(pos);

    for (int r : requests) {
        movimientoTotal += abs(pos - r);
        pos = r;
        path.push_back(pos);
    }

    return movimientoTotal;
}

// SCAN (subiendo)

int calcularSCAN(vector<int> requests, int head, vector<int> &path) {
    int movimientoTotal = 0;
    int pos = head;

    sort(requests.begin(), requests.end());

    vector<int> menores, mayores;
    for (int r : requests) {
        if (r < head) menores.push_back(r);
        else mayores.push_back(r);
    }
    reverse(menores.begin(), menores.end());

    path.push_back(pos);

    // Subir
    for (int r : mayores) {
        movimientoTotal += abs(pos - r);
        pos = r;
        path.push_back(pos);
    }

    // Llegar al tope
    movimientoTotal += abs(pos - top);
    pos = top;
    path.push_back(pos);

    // Bajar
    for (int r : menores) {
        movimientoTotal += abs(pos - r);
        pos = r;
        path.push_back(pos);
    }

    return movimientoTotal;
}

// C-SCAN (subiendo)

int calcularCSCAN(vector<int> requests, int head, vector<int> &path) {
    int movimientoTotal = 0;
    int pos = head;

    sort(requests.begin(), requests.end());

    vector<int> menores, mayores;
    for (int r : requests) {
        if (r < head) menores.push_back(r);
        else mayores.push_back(r);
    }

    path.push_back(pos);

    // Subir
    for (int r : mayores) {
        movimientoTotal += abs(pos - r);
        pos = r;
        path.push_back(pos);
    }

    // Ir al tope físico
    movimientoTotal += abs(pos - top);
    pos = top;
    path.push_back(pos);

    // Salto lógico
    movimientoTotal += top;      // 4999 → 0
    pos = 0;
    path.push_back(pos);

    // Atender menores
    for (int r : menores) {
        movimientoTotal += abs(pos - r);
        pos = r;
        path.push_back(pos);
    }

    return movimientoTotal;
}

int main(int argc, char *argv[]) {

    if (argc != 2) {
        cout << "Uso: ./assignment3 <posicion_inicial>\n";
        return 1;
    }

    int head = atoi(argv[1]);

    // Requests manuales
    vector<int> requests; // = {2069, 1212, 2296, 2800, 544, 1618, 356, 1523, 4965, 3681};

    // Generación aleatoria
    
    srand(time(NULL));
    requests.clear();
    requests.reserve(1000);
    for (int i = 0; i < 1000; i++) {
        requests.push_back(rand() % (top + 1));
    }
    
    vector<int> pathFCFS, pathSCAN, pathCSCAN;

    int fcfs  = calcularFCFS(requests, head, pathFCFS);
    int scan  = calcularSCAN(requests, head, pathSCAN);
    int cscan = calcularCSCAN(requests, head, pathCSCAN);

    exportarCSV("fcfs.csv", pathFCFS);
    exportarCSV("scan.csv", pathSCAN);
    exportarCSV("cscan.csv", pathCSCAN);

    cout << "FCFS  : " << fcfs << endl;
    cout << "SCAN  : " << scan << endl;
    cout << "C-SCAN: " << cscan << endl;

    cout << "\nCSV generados: fcfs.csv, scan.csv, cscan.csv\n";

    // Llamar a Python para graficar
    
    cout << "Ejecutando graficar.py...\n";
    int resultado = system("python graficar.py");

    if (resultado != 0) {
        cout << "No funcionó con 'python'. Intentando con 'python3'...\n";
        resultado = system("python3 graficar.py");
    }

    if (resultado == 0) {
        cout << "Graficas generadas correctamente.\n";
    } else {
        cout << "ERROR: No se pudo ejecutar el script de Python.\n";
    }

    return 0;
}